import { describe, it, expect } from "@jest/globals";
import { Estoque } from "../src/core/estoque";
import { Produto } from "../src/core/produto";
import { Entrada, Saida } from "../src/core/movimentacao";
import { EstoqueInsuficienteError } from "../src/core/errors";

describe("Estoque", () => {
  it("cadastra e soma valor total", () => {
    const e = new Estoque();
    e.cadastrar(new Produto("Arroz", "A1", 10, 5));
    e.cadastrar(new Produto("Feijão", "F1", 8, 10));
    const r = e.relatorio();
    expect(r.totalItens).toBe(15);
    expect(r.valorTotal).toBe(10 * 5 + 8 * 10);
  });

  it("entrada e saída", () => {
    const e = new Estoque();
    e.cadastrar(new Produto("Milho", "M1", 3, 2));
    e.registrar(new Entrada("M1", 5));
    e.registrar(new Saida("M1", 3));
    expect(e.obter("M1").quantidade).toBe(4);
  });

  it("bloqueia saída maior que estoque", () => {
    const e = new Estoque();
    e.cadastrar(new Produto("Soja", "S1", 7, 1));
    expect(() => e.registrar(new Saida("S1", 2))).toThrow(EstoqueInsuficienteError);
  });
});