import readline from "node:readline/promises";
import { stdin as input, stdout as output } from "node:process";
import { Estoque } from "./core/estoque";
import { Produto } from "./core/produto";
import { Entrada, Saida } from "./core/movimentacao";
import {
  DadosInvalidosError,
  EstoqueInsuficienteError,
  ProdutoJaExisteError,
  ProdutoNaoEncontradoError
} from "./core/errors";

const rl = readline.createInterface({ input, output });
const estoque = new Estoque();

async function pergunta(txt: string) {
  const r = await rl.question(txt);
  return r.trim();
}

function toInt(s: string, nome: string) {
  const n = Number(s);
  if (!Number.isInteger(n)) throw new DadosInvalidosError(`${nome} deve ser inteiro.`);
  return n;
}
function toFloat(s: string, nome: string) {
  const n = Number(s);
  if (!Number.isFinite(n)) throw new DadosInvalidosError(`${nome} inválido.`);
  return n;
}

async function cadastrarProduto() {
  try {
    const nome = await pergunta("Nome: ");
    const codigo = await pergunta("Código: ");
    const preco = toFloat(await pergunta("Preço: "), "Preço");
    const qtd = toInt(await pergunta("Quantidade inicial: "), "Quantidade");
    const minimo = toInt(await pergunta("Estoque mínimo (opcional, padrão 0): "), "Estoque mínimo");
    const p = new Produto(nome, codigo, preco, qtd, minimo);
    estoque.cadastrar(p);
    console.log("✅ Produto cadastrado!\n");
  } catch (e) {
    trataErro(e);
  }
}

async function registrarEntradaSaida(tipo: "E" | "S") {
  try {
    const codigo = await pergunta("Código do produto: ");
    const qtd = toInt(await pergunta("Quantidade: "), "Quantidade");
    const mov = tipo === "E" ? new Entrada(codigo, qtd) : new Saida(codigo, qtd);
    estoque.registrar(mov);
    console.log(tipo === "E" ? "✅ Entrada registrada!\n" : "✅ Saída registrada!\n");
  } catch (e) {
    trataErro(e);
  }
}

function gerarRelatorio() {
  const r = estoque.relatorio();
  console.log("\n=== RELATÓRIO DE ESTOQUE ===");
  console.table(r.produtos.map(p => ({
    Código: p.codigo,
    Nome: p.nome,
    Preço: p.preco,
    Quantidade: p.quantidade,
    Valor: p.valor.toFixed(2),
    "Abaixo Mín.": p.abaixoMinimo ? "⚠️" : ""
  })));
  console.log(`Total de itens: ${r.totalItens}`);
  console.log(`Valor total: R$ ${r.valorTotal.toFixed(2)}\n`);
}

function trataErro(e: unknown) {
  if (e instanceof DadosInvalidosError
    || e instanceof EstoqueInsuficienteError
    || e instanceof ProdutoJaExisteError
    || e instanceof ProdutoNaoEncontradoError) {
    console.error("Erro:", e.message, "\n");
  } else {
    console.error("Erro inesperado:", e, "\n");
  }
}

async function main() {
  console.log("=== Sistema de Monitoramento de Pedidos em Estoque (MOD2) ===\n");
  while (true) {
    console.log("1) Cadastrar produto");
    console.log("2) Registrar ENTRADA");
    console.log("3) Registrar SAÍDA");
    console.log("4) Relatório de estoque");
    console.log("5) Histórico de movimentações");
    console.log("0) Sair");
    const op = await pergunta("> Escolha: ");

    switch (op) {
      case "1": await cadastrarProduto(); break;
      case "2": await registrarEntradaSaida("E"); break;
      case "3": await registrarEntradaSaida("S"); break;
      case "4": gerarRelatorio(); break;
      case "5":
        console.table(estoque.historico().map(h => ({
          Data: h.data.toISOString(),
          Tipo: h.tipo(),
          Produto: h.codigoProduto,
          Quantidade: h.quantidade,
          "Preço (na época)": h.valorUnitario
        })));
        break;
      case "0":
        console.log("Até mais!");
        await rl.close();
        return;
      default:
        console.log("Opção inválida.\n");
    }
  }
}

main().catch(err => {
  console.error("Falha crítica:", err);
  rl.close();
});