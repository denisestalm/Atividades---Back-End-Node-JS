import { DadosInvalidosError, EstoqueInsuficienteError } from "./errors";
import { Produto } from "./produto";

export abstract class Movimentacao {
  readonly data: Date;
  readonly codigoProduto: string;
  readonly quantidade: number;

  constructor(codigoProduto: string, quantidade: number, data = new Date()) {
    if (!codigoProduto?.trim()) throw new DadosInvalidosError("Código de produto obrigatório.");
    if (!Number.isInteger(quantidade) || quantidade <= 0) throw new DadosInvalidosError("Quantidade inválida.");
    this.codigoProduto = codigoProduto.trim();
    this.quantidade = quantidade;
    this.data = data;
  }

  abstract aplicar(produto: Produto): void;
  abstract tipo(): "ENTRADA" | "SAIDA";
}

export class Entrada extends Movimentacao {
  aplicar(produto: Produto): void { produto.entrada(this.quantidade); }
  tipo(): "ENTRADA" { return "ENTRADA"; }
}

export class Saida extends Movimentacao {
  aplicar(produto: Produto): void {
    if (produto.quantidade < this.quantidade) throw new EstoqueInsuficienteError("Estoque insuficiente para saída.");
    produto.saida(this.quantidade);
  }
  tipo(): "SAIDA" { return "SAIDA"; }
}