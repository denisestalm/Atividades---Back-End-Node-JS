export interface Identificavel {
  codigo: string;
}

export interface RelatorioEstoque {
  totalItens: number;
  valorTotal: number; // somatório preço * quantidade
  produtos: Array<{
    codigo: string;
    nome: string;
    preco: number;
    quantidade: number;
    valor: number;
    abaixoMinimo?: boolean;
  }>;
}