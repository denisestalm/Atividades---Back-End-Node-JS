import { DadosInvalidosError } from "./errors";
import type { Identificavel } from "./types";

export class Produto implements Identificavel {
  #nome: string;
  #codigo: string;
  #preco: number;
  #quantidade: number;
  #estoqueMinimo: number;

  constructor(nome: string, codigo: string, preco: number, quantidadeInicial: number, estoqueMinimo = 0) {
    if (!nome?.trim() || !codigo?.trim()) throw new DadosInvalidosError("Nome e código são obrigatórios.");
    if (preco < 0) throw new DadosInvalidosError("Preço não pode ser negativo.");
    if (!Number.isInteger(quantidadeInicial) || quantidadeInicial < 0) throw new DadosInvalidosError("Quantidade inicial inválida.");
    if (!Number.isInteger(estoqueMinimo) || estoqueMinimo < 0) throw new DadosInvalidosError("Estoque mínimo inválido.");

    this.#nome = nome.trim();
    this.#codigo = codigo.trim();
    this.#preco = preco;
    this.#quantidade = quantidadeInicial;
    this.#estoqueMinimo = estoqueMinimo;
  }

  get nome() { return this.#nome; }
  set nome(v: string) {
    if (!v?.trim()) throw new DadosInvalidosError("Nome inválido.");
    this.#nome = v.trim();
  }

  get codigo() { return this.#codigo; } // sem setter: imutável

  get preco() { return this.#preco; }
  set preco(v: number) {
    if (v < 0) throw new DadosInvalidosError("Preço inválido.");
    this.#preco = v;
  }

  get quantidade() { return this.#quantidade; } // alteração só via métodos controlados
  get estoqueMinimo() { return this.#estoqueMinimo; }
  set estoqueMinimo(v: number) {
    if (!Number.isInteger(v) || v < 0) throw new DadosInvalidosError("Estoque mínimo inválido.");
    this.#estoqueMinimo = v;
  }

  entrada(qtd: number) {
    if (!Number.isInteger(qtd) || qtd <= 0) throw new DadosInvalidosError("Quantidade de entrada inválida.");
    this.#quantidade += qtd;
  }

  saida(qtd: number) {
    if (!Number.isInteger(qtd) || qtd <= 0) throw new DadosInvalidosError("Quantidade de saída inválida.");
    if (this.#quantidade < qtd) throw new DadosInvalidosError("Saída maior que o estoque atual.");
    this.#quantidade -= qtd;
  }

  get abaixoDoMinimo(): boolean {
    return this.#quantidade < this.#estoqueMinimo;
  }

  valorTotal(): number {
    return this.#preco * this.#quantidade;
  }
}