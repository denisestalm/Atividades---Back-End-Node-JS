export class DadosInvalidosError extends Error {
  constructor(msg = "Dados inválidos") { super(msg); this.name = "DadosInvalidosError"; }
}
export class EstoqueInsuficienteError extends Error {
  constructor(msg = "Estoque insuficiente") { super(msg); this.name = "EstoqueInsuficienteError"; }
}
export class ProdutoJaExisteError extends Error {
  constructor(msg = "Produto já cadastrado") { super(msg); this.name = "ProdutoJaExisteError"; }
}
export class ProdutoNaoEncontradoError extends Error {
  constructor(msg = "Produto não encontrado") { super(msg); this.name = "ProdutoNaoEncontradoError"; }
}