import { Produto } from "./produto";
import { ProdutoJaExisteError, ProdutoNaoEncontradoError } from "./errors";
import type { RelatorioEstoque } from "./types";
import type { Movimentacao } from "./movimentacao";

export class Estoque {
  #produtos = new Map<string, Produto>();
  #historico: Array<Movimentacao & { valorUnitario: number }> = [];

  cadastrar(produto: Produto) {
    if (this.#produtos.has(produto.codigo)) throw new ProdutoJaExisteError();
    this.#produtos.set(produto.codigo, produto);
  }

  obter(codigo: string): Produto {
    const p = this.#produtos.get(codigo);
    if (!p) throw new ProdutoNaoEncontradoError();
    return p;
  }

  registrar(mov: Movimentacao) {
    const p = this.obter(mov.codigoProduto);
    mov.aplicar(p);
    this.#historico.push(Object.assign(mov, { valorUnitario: p.preco }));
  }

  relatorio(): RelatorioEstoque {
    const produtos = Array.from(this.#produtos.values()).map(p => ({
      codigo: p.codigo,
      nome: p.nome,
      preco: p.preco,
      quantidade: p.quantidade,
      valor: p.valorTotal(),
      abaixoMinimo: p.abaixoDoMinimo || undefined
    }));
    const totalItens = produtos.reduce((s, x) => s + x.quantidade, 0);
    const valorTotal = produtos.reduce((s, x) => s + x.valor, 0);
    return { totalItens, valorTotal, produtos };
  }

  historico() {
    // relatório simples do histórico (poderia ser expandido com filtros/data)
    return this.#historico.slice();
  }
}