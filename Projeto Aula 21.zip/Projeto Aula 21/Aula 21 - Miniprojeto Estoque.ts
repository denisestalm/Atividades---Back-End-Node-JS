/* Projeto MOD2 - Sistema de Monitoramento de Pedidos em estoque.

Objetivo:
- Desenvolver um sistema back-end em TypeScript para controles de estoque.
- Aplicar conceitos de orientação a objetos: classes, objetos, encapsulmento, herança, polimorfismo, interfaces.
- Implementar testes de software e tratamento de exceções.

Funcionalidades:
- Cadastro de produtos com nome, código, preço e quantidade inicial;
- Registro de entrada e saída de produtos;
- Emissão de alertas de estoque baixo;
- Geração de relatórios de estoque atual e histórico de movimentações.

Estrutura OD:
- Produto, nome, código, preço, quantidade (privado);
- Movimentação: superclasse de entrada e saídas;
- Entrada / Saída herdam Movimentação, registram alterações do estoque;
- Estoque: gerencia produtos, movimentações e relatórios.

Requisitos técnicos:
- Uso de typescript com conceitos OO;
- Aplicar encapsulamento (atributos privados e getters/setters);
- Usar herança e polimorfismo nas movimentações;
- Implementar tratamento de exceções (estoque insuficiente, dados inválidos);
- Criar testes unitários para métodos críticos.

Funcionalidades:
- Menu interativo, o sistema deve possuir Menu para:
- Cadastrar produto;
- Registrar entrada;
- Registrar saída;
- Gerar relatório de estoque;
- Sair do sistema, menu em loop até o usuário escolher sair.

Dicas: 
- Comece com modelagem de classes / UML Simplificada;
- Teste cada classe isoladamente antes de integrar;
- Mantenha encapsulamento, nunca alterar estoque diretamente fora dos métodos;
- Documente todos os métodos com comentários explicativos.

Desafios extras:
- Calcular valor total do estoque;
- Registrar múltiplas entradas e saídas de forma automática (ex. lote de produtos);
- Implementar alerta se algum produto estiver abaixo de estoque mínimo definido;
- (Opcional) Salvar dados em arquivo ou banco de ddos.*/